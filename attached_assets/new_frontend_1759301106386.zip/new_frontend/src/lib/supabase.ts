import { createBrowserClient, createServerClient } from '@supabase/ssr'
import { supabaseConfig } from '../config/supabase'

// Supabase configuration - following the recommended approach
const { url: supabaseUrl, anonKey: supabaseAnonKey, serviceRoleKey } = supabaseConfig

// Browser client for client-side operations with RLS
export const supabase = createBrowserClient(supabaseUrl, supabaseAnonKey)

// Server client for privileged operations (would be used in server actions/API routes)
export function createServerSupabaseClient() {
  return createServerClient(
    supabaseUrl,
    serviceRoleKey, // server only
    {
      cookies: {
        get: (name: string) => {
          // In a Vite environment, cookies would be handled differently
          // This is a placeholder for proper cookie handling
          return document.cookie
            .split('; ')
            .find(row => row.startsWith(`${name}=`))
            ?.split('=')[1]
        },
        set: (name: string, value: string, options: any) => {
          // Placeholder for cookie setting in browser environment
          document.cookie = `${name}=${value}; path=/`
        },
        remove: (name: string, options: any) => {
          document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`
        },
      },
    }
  )
}

// Types for Supabase Realtime
export interface AlertSignalRealtime {
  id: string
  user_id: string | null
  ticker: string
  signal_type: 'buy' | 'sell'
  price: number
  timestamp: string
  timeframe: string
  strategy?: string
  source: string
  note?: string
  created_at: string
}

export interface RealtimePayload {
  new: AlertSignalRealtime
  old?: AlertSignalRealtime
  eventType: 'INSERT' | 'UPDATE' | 'DELETE'
}