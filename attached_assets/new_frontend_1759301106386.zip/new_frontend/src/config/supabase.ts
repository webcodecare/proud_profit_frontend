// Supabase configuration with proper environment variable handling
export const supabaseConfig = {
  url: (import.meta as any).env?.VITE_SUPABASE_URL || 'https://your-project.supabase.co',
  anonKey: (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'your-anon-key',
  serviceRoleKey: (import.meta as any).env?.VITE_SUPABASE_SERVICE_ROLE_KEY || '',
}